
*******************************Release Note******************************************

This Package is for R9M Lite Access firmware update. F irmware under LBT mode will be released soon.

Version and Files: 
 R9M_Lite_LBT_Access_190730.frk               Firmware under LBT mode which is certificated for CE rules. 
 R9M_Lite_FCC_Access_190611.frk               Firmware under NonLBT mode which is certificated for FCC rules. 
 R9M_Lite_FLEX_Access_190611.frk              Firmware under Flex mode please check local rules before use it .
 readme.txt                                                      release note 
 
Firmware Version:1.1.1
Date:20190611 for FCC and FLEX
Date:20190730 for LBT

The release firmware resolved the issues below:
--------------------------------------------------------------------------------------------------------------------
1. Add support for Access protocol which brings many new features and improves performance.


More details please check ACCESS introduction on FrSky website.
https://www.frsky-rc.com/frsky-advanced-communication-control-elevated-spread-spectrum-access-protocol-release/

**********************All rights reserved to FrSky Electronic ., Ltd.*********************************
