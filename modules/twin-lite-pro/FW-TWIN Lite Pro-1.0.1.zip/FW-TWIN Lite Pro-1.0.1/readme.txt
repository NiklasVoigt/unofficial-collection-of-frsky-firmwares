
*******************************Release Note******************************************

This Package is for Twin Lite Pro firmware update. 

Version and Files: 
TW-Lite Pro_1.0.1.frsk                                          Firmware for Twin Lite Pro RF Module.
readme.txt                                                           Release note 
 
Firmware Version: v1.0.1

The first release.
-------------------------------------------------------------------------------------------------------------------

How to update Twin Lite Pro firmware :
By radio (SD card) :
1. Put the firmware under the folder [FIRMWARE] of sd card.
2. Plug in Twin Lite Pro into the module bay of the radio which has Lite style module bay.
3. Power on the radio and find the firmware,select it by press [ENT].
4. Select 'Flash ext. module', wait to end.
---------------------------------------------------------------------------------------------------------------------
More details please check FrSky website:
https://www.frsky-rc.com/product/twin-lite-pro/

**********************All rights reserved to FrSky Electronic ., Ltd.*********************************
