
*******************************Release Note******************************************

This Package is for Twin Lite Pro firmware update. 

Version and Files: 
TW-Lite Pro_1.0.6.frsk                                          Firmware for Twin Lite Pro RF Module.
readme.txt                                                           

Release Note 

Firmware Version: 【v1.0.6】
1. Added the support for RemoteNFC Panel.
-------------------------------------------------------------------------------------------------------------------

Firmware Version: 【v1.0.5】
1. Improved the VFR capability and anti-interference performance.
2. Improved real-time transmission performance of failsafe data.
Note: To work with this firmware update of the Twin Lite Pro module, please make sure the firmware of the TW series receiver is upgraded to 1.0.5/1.0.6 or the latest version.
-------------------------------------------------------------------------------------------------------------------

Firmware Version: 【v1.0.4】
1. Added the support of working with TW R8 and TW GR8 receivers.
Note: To work with this firmware update of Twin Lite Pro module, please make sure the firmware of the TW series receiver is upgraded to 1.0.4 or later version. 
-------------------------------------------------------------------------------------------------------------------

How to update Twin Lite Pro firmware :
By radio (SD card) :
1. Put the firmware under the folder [FIRMWARE] of sd card.
2. Plug in Twin Lite Pro into the module bay of the radio which has Lite style module bay.
3. Power on the radio and find the firmware,select it by press [ENT].
4. Select 'Flash ext. module', wait to end.
---------------------------------------------------------------------------------------------------------------------
More details please check FrSky website:
https://www.frsky-rc.com/product/twin-lite-pro/

**********************All rights reserved to FrSky Electronic ., Ltd.*********************************
