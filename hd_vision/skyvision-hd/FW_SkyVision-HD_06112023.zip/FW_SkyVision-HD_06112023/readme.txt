
*******************************Release Note******************************************

This Package is for SkyVision HD firmware update. 

Version and Files: 
FW-SkyVision-HD_06112023.zip         Firmware for SkyVision HD.
readme.txt                                         

Release Note (v06112023)
----------------------------------------------------------------------------------------
1. Added the 90Hz refresh rate support of working compatible with 90Hz capable devices.
----------------------------------------------------------------------------------------

How to update SkyVision HD firmware :
1. Put all the unzipped firmware in the root directory of the TF card.
2. Turn off the SkyVision HD and insert the TF card into the card slot of the device.
3. Repower SkyVision HD and the device will run the upgrade procedure automatically.
4. The monitor will show "Upgrade Successfully" after upgrading the firmware, then repowering the device manually is required.

-----------------------------------------------------------------------------------------
More details please check FrSky website.
https://www.frsky-rc.com/product/skyvision-hd/



**********************All rights reserved to FrSky Electronic ., Ltd.*********************************
