
*******************************Release Note******************************************

This Package is for SkyVision HD firmware update. 

Version and Files: 
FW-SkyVision-HD_04262024.zip         Firmware for SkyVision HD.
readme.txt                                         

Release Note (v04262024)
----------------------------------------------------------------------------------------
1. Fixed the displaying issue of OSD only working under the video recording mode.
----------------------------------------------------------------------------------------


Release Note (v06112023)
----------------------------------------------------------------------------------------
1. Added the 90Hz refresh rate support of working compatible with 90Hz capable devices.
----------------------------------------------------------------------------------------

How to update SkyVision HD firmware :
1. Put all the unzipped firmware in the root directory of the TF card.
2. Turn off the SkyVision HD and insert the TF card into the card slot of the device.
3. Repower SkyVision HD and the device will run the upgrade procedure automatically.
4. The monitor will show "Upgrade Successfully" after upgrading the firmware, then repowering the device manually is required.

How to reflash the firmware when the normal upgrade process with no success:
1. Find the switch mounted on the board through the 3rd vent holes at the right side of the bottom. 
2. Try to use a needle or a stick to switch modes for having the SkyVision enter into the emergency flash mode.
3. Then repeat the upgrade progress until you have the firmware upgrade successfully.
Notice: When the notice "Firmware update successfully" prompts on the screen, please remember to switch back before repowering the system.
-----------------------------------------------------------------------------------------
More details please check FrSky website.
https://www.frsky-rc.com/product/skyvision-hd/



**********************All rights reserved to FrSky Electronic ., Ltd.*********************************
