notes:

FrSky has improved the performance of the BK-RF board of Taranis X9D Plus since Nov. 15th, 2016.
For those with production dates between Nov. 15th, 2016 to Dec. 23rd, 2016, 
if you’d like to use with LR12 mode (L9R receiver), pls flash the firmware to Ver161214. 
For those with production dates earlier than Nov. 15th, 2016, no need to flash the firmware. 
For those with production dates later than Dec. 23rd, 2016, Ver161214 firmware will be as default.