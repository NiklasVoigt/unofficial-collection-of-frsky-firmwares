readme
Fix the bug of no output in ELE channel sometimes
