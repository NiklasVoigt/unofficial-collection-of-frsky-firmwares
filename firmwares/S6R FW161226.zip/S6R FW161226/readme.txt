readme
1. Fix the bug of jump of channel 5-8
2. Channel pass midpoint 3 times in 3 seconds will enter self-check
3. PC config add load and save config file
4. In DELTA, the rudder stabilization will have no effect when CH10 in the center
5. Change the way into self-check: CH12 continuously switches to midpoint 5 times within 5 seconds
6. RF adapt to DH16V2
7. Self-check will start when CH12 moves to center longer than 1 second
8. Channel AUX1 or AIL2, AUX2 or ELE2 can be selected in S6R
9. Fix CRC bugs in S6R/STK/PC config
10. Message queue will be reset when time out in STK
11. Rud with stablization in delta wing mod

Note: S6R/STK/PC config/Lua script all need update