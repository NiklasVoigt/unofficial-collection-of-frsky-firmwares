
*******************************Release Note******************************************

This Package is for R9 Slim+ OTA ACCESS firmware update. 

Version and Files: 
 R9Slim+_OTA_LBT.frsk                                            Firmware under LBT mode which is certificated for CE rules.  
 R9Slim+_OTA_FCC.frsk                                            Firmware under NonLbt mode which is certificated for FCC rules. 
 R9Slim+_OTA_FLEX.frsk                                           Firmware under Flex mode please check local rules before use it .
 readme.txt                                                                        Release note 
 
Note: F.port output canbe enabled in radio menu.
 
Firmware Version: v1.3.0

The release firmware resolved the issues below:
--------------------------------------------------------------------------------------------------------------------
1. Improved RF performance.
2. Added the telemetry for LFR (Lost Frame Rate).
--------------------------------------------------------------------------------------------------------------------

More details please check the link below on FrSky website.
https://www.frsky-rc.com/product/r9-slim-ota/


**********************All rights reserved to FrSky Electronic ., Ltd.*********************************