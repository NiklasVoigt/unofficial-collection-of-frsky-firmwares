
*******************************Release Note******************************************

This Package is for R9 STAB OTA ACCST firmware update. 

Version and Files: 
 R9Stab_LBT.frk                                            Firmware under LBT mode which is certificated for CE rules.  
 R9Stab_FCC.frk                                           Firmware under NonLbt mode which is certificated for FCC rules. 
 R9Stab_FLEX.frk                                          Firmware under Flex mode please check local rules before use it .
 readme.txt                                                  Release note 
 

Firmware Version:20191022

The release firmware resolved the issues below:
--------------------------------------------------------------------------------------------------------------------
1. First release which is compatible to ACCST protocol.


More details please check the link below on FrSky website.
https://www.frsky-rc.com/frsky-access-r9-family-r9-stab-ota-long-range-and-stabilization-receiver-release/
https://www.frsky-rc.com/product/r9-stab-ota/


**********************All rights reserved to FrSky Electronic ., Ltd.*********************************