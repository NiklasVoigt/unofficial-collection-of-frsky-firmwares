
*******************************Release Note******************************************

This Package is for ACCST firmware update for G-RX8. 

Version and Files: 
G-RX8_FCC_ACCST_191115.frk                          Firmware under NonLbt mode which is certificated for FCC rules.
G-RX8_LBT_ACCST_191115.frk                          Firmware under LBT mode which is certificated for CE rules.
readme.txt                                                          Release note 
 
Firmware Version: v191115

The release firmware resolved the issues below:
--------------------------------------------------------------------------------------------------------------------
-Fixed the problem of abnormal high frame loss rate.


More details please check the link below on FrSky website.
https://www.frsky-rc.com/product/g-rx8/

**********************All rights reserved to FrSky Electronic ., Ltd.*********************************