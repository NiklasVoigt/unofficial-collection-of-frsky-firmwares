
*******************************Release Note******************************************

This Package is for R9MX firmware update. 

Version and Files: 
R9MX_LBT.frsk                                 LBT (certificate for CE )Firmware for R9MX. 
R9MX_FCC.frsk                                Non-LBT (certificate for FCC )Firmware for R9MX. 
R9MX_FLEX.frsk                               FLEX Firmware(No certificate) for R9MX,please check local rules before use.

readme.txt                                         Release note 

F.port / S.Port can be switched in the radio menu.

Firmware Version: v1.3.2

The release firmware resolved the issues below:
--------------------------------------------------------------------------------------------------------------------
First release
-------------------------------------------------------------------------------------------------------------------
How to update R9MX firmware :
1. Put the firmware under the folder [FIRMWARE] of sd card.
2. Register and bind the receiver with your radio, keep the receiver under working mode. 
3. Find the firmware in SD folder, select it by press [ENT].
4. Select Flash receiver OTA, re-cycle the receiver power and wait for flash ends.
5. Re-cycle the receiver power and wait for 3 seconds to have connection with your radio again.

Note: Receiver is still supported with flashing firmware by s.port connection to radio.
---------------------------------------------------------------------------------------------------------------------
More details please check FrSky website:
https://www.frsky-rc.com/product/r9-mx/

**********************All rights reserved to FrSky Electronic ., Ltd.*********************************
