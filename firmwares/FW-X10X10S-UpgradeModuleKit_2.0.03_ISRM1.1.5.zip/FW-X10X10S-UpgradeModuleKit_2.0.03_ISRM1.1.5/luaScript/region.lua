local VERSION = "2.2"

local VALUE = 0
local COMBO = 1

local TA_LEFT = 0
local TA_RIGHT = 1

local fields = {}

local printText = (0x800 + 0x02)
local hPWin = 0
local current
local editMode = false
local modifications = {}
local refreshState = 0
local pageOffset = 0
local page = 1
local pages = {}
local field

local b4Power
local b5Band
local b6Channel

local configFields = {
  {"region", COMBO, 0x55, nil,{ "EU", "N-EU" }, {0 , 1}}
}


local function telemetryRead(field)  
  local valuex = 0x55 + 0x55*0x100+0xAA*0x10000+0xA0*0x1000000
  return sport.TelemetryPush(0x17, 0x30, 0x0C40, valuex)
end

local function telemetryIdle(field)
  return sport.TelemetryPush(0x17, 0x21, 0x0C40, field)
end

local function telemetryUnIdle(field)
  return sport.TelemetryPush(0x17, 0x20, 0x0C40, field)
end

local function telemetryWrite(field,valuex)   
  if 0 == valuex then
    valuex = 0x55 + 0x55*0x100+0xAA*0x10000+0xA0*0x1000000
  else
    valuex = 0x55 + 0x55*0x100+0xAA*0x10000+0xA1*0x1000000
  end
  return sport.TelemetryPush(0x17, 0x31, 0x0C40, valuex)
end


-- Redraw the current page
local function redrawFieldsPage(hWin)

  if #fields > NUM_PER_PAGE then
    drawScrollbar(hWin, #fields, NUM_PER_PAGE, pageOffset)
  end
  
	for index = 1, NUM_PER_PAGE, 1 do
		local field = fields[pageOffset+index]
		if field == nil then
		  break
		end		
    
    drawText(hWin, index-1, field[1], TA_LEFT)
    
		if field[4] == nil then
			if field[2] == VALUE then
				drawEdit(hWin, index-1, "---")
			elseif field[2] == COMBO then			
				drawDropdown(hWin, index-1, 0, "---")
			end	
		else
      if field[2] == VALUE then
        drawEdit(hWin, index-1, field[4], field[5], field[6], 0) 
      elseif field[2] == COMBO then
        if field[4] >= 0 and field[4] < #(field[5]) then		
          local attr = field[5][1].."|"
          for index2 = 2,  #(field[5]), 1 do
            attr = attr..field[5][index2]
            if index2 <= #(field[5]) then
              attr = attr.."|"
            end
          end		
          
        --setWValue(hPWin, printText, "chan="..fields[1][4].." 2="..b5Band.." 3="..b6Channel)
        drawDropdown(hWin, index-1, field[4], attr)
        end
      end
    end
  end
end


local function refreshNext()  
  if refreshState == 0 then  
    if #modifications > 0 then      
      local modificationstmp = modifications[1][2]		
      telemetryWrite(modifications[1][1], modificationstmp)
      refreshIndex = 0
      modifications[1] = nil
    elseif refreshIndex < #fields then
			local field = fields[refreshIndex + 1]      
			if telemetryRead(field[3]) == true then     
				refreshState = 1
				telemetryPopTimeout = getTime() + 200 -- normal delay is 500ms
			end
    end
	elseif refreshState == 1 then
		local appId, primId, value = sport.TelemetryPop()    
      
    if appId >= 0X0C40 and appId <= 0X0C4f and primId == 0x32 then          
     
      local fieldId = value % 256
      local field = fields[refreshIndex + 1]
      if fieldId == field[3] then
        local value = math.floor(value / 0x1000000)-0xA0
        if field[2] == VALUE  then
          value = value
        end
        fields[refreshIndex + 1][4] = value
        refreshIndex = refreshIndex + 1
        refreshState = 0
	  end
	elseif getTime() > telemetryPopTimeout then 
		refreshState = 0
	end
  end
end

-- Main
local function runFieldsPage(hWin, Key)  
  redrawFieldsPage(hWin)
  return 0
end

local function runConfigPage(hWin, Key)
  fields = configFields
  local result
  if false == editMode then
    result = runFieldsPage(hWin, Key)          
  end
  return result
end


-- Select the next or previous page
local function selectPage(step)
  page = 1 + ((page + step - 1 + #pages) % #pages)
  
  current, edit, refreshState, refreshIndex, pageOffset = 1, false, 0, 0, 0
  
  clearAll(hPWin)  
end

-- Select the next or previous editable field
local function selectField(step)
  local retValue = 1
  current = current + step  
  
  if current > #fields then
    current = #fields 
  elseif current < 1 then  
    current = 1
  elseif current > NUM_PER_PAGE + pageOffset then
    pageOffset = current - NUM_PER_PAGE
  elseif current <= pageOffset then
    pageOffset = current - 1 
  else
    retValue = 0
  end
  
  return retValue
end


local function updateField(field)
  local value = field[4]
  if nil ~= value then
    value = getWValue(current-pageOffset-1, field[2])
    
    modifications[#modifications+1] = { field[3], value }
    
    field[4] = value
  end  
end

-- Init
function init()
	current, edit, refreshState, refreshIndex = 1, false, 0, 0
  
	pages = {
		runConfigPage
	}
  
  telemetryIdle(0x80)
end

--run
function runLua(hWin, Key)
  hPWin = hWin
  local result = 0
    
	if Key == 0 then
		result = 0
	elseif Key == 1 then     
    --result = runConfigPage(hWin,Key)
  elseif Key == KEY_ENT then 
  
    if true == editMode then      
      updateField(fields[current])
    end   

    editMode = not editMode      
  elseif Key == KEY_TAB then
    result = selectField(1)
  elseif Key == KEY_BACKTAB then
    result = selectField(-1)    
  elseif Key == KEY_PG_DN then
    --selectPage(1)
  elseif Key == KEY_PG_UP then
    --selectPage(-1)
  elseif Key == KEY_RTN_R then 
    clearAll(hWin)
  else 
    
	end  
  
  drawTitle(hPWin, "region", page, #pages)
  
  pages[page](hWin,Key)
  
	refreshNext()

	return result
 end
