Firmware Explanations and uses R168

Firmware File Name		Firmware Use
R168_V1_(EU)LBT.frk		LBT Firmware - D16 v1
R168_V1_FCC.frk			FCC Firmware - D16 v1		

Firmware File Name		Firmware Use
R168_V2_(EU)LBT.frk		LBT Firmware - D16 v2.1.0
R168_V2_FCC.frk			FCC Firmware - D16 v2.1.0