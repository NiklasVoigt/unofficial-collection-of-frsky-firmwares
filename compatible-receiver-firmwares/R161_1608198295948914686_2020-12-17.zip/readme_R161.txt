Firmware Explanations and uses.

Firmware File Name		Firmware Use
R161_V1_FPORT EU.frk		LBT Firmware for F.Port use - D16 v1
R161_V1_FPORT FCC.frk		FCC Firmware for F.Port use - D16 v1		
R161_V1_SPORT EU.frk		FCC Firmware for Sbus/S.Port - D16 v1
R161_V1_SPORT FCC.frk		FCC Firmware for Sbus/S.Port - D16 v1

Firmware File Name		Firmware Use
R161_V2_FCC.frk			FCC Firmware for Sbus/S.Port - D16 v2.1.0
R161_V2_LBT.frk			LBT Firmware for Sbus/S.Port - D16 v2.1.0
R161_V2_Fport_FCC.frk		FCC Firmware for F.Port use - D16 v2.1.0
R161_V2_Fport_LBT.frk		LBT Firmware for F.Port use - D16 v2.1.0
