
*******************************Release Note******************************************

This Package is for ACCST firmware update for RXSR-FC.

Version and Files: 
RXSR-FC_ACCST_FCC_191128.frk                            Firmware under NonLbt mode which is certificated for FCC rules.
RXSR-FC_ACCST_LBT_191128.frk                            Firmware under LBT mode which is certificated for CE rules.

readme.txt                                                               Release note 
 
Firmware Version: v191128

The release firmware resolved the issues below:
--------------------------------------------------------------------------------------------------------------------
-Fixed the problem of abnormal high frame loss rate.


More details please check the link below on FrSky website.
https://www.frsky-rc.com/product/rxsr-fc-omnibus-f4-nano-v7/
https://www.frsky-rc.com/product/rxsr-fc-omninxt-f7/
https://www.frsky-rc.com/product/rxsr-fc-omnibus-f4-fireworks-v2/
https://www.frsky-rc.com/product/rxsr-fc-omnibus-f4-v6/
https://www.frsky-rc.com/product/rxsrf3om/
**********************All rights reserved to FrSky Electronic ., Ltd.*********************************