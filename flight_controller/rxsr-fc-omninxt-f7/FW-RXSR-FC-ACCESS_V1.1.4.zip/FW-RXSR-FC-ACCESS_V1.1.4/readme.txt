
*******************************Release Note******************************************

This Package is for ACCESS v1.1.4 firmware update for RXSR-FC. 

Version and Files: 
RXSR-FC_ACCESS_191107.frsk                          Upgrade file for RXSR-FC

readme.txt                                                         Release note 
 
Firmware Version: v1.1.4
Date:20191107

The release firmware resolved the issues below:
--------------------------------------------------------------------------------------------------------------------
 Fix the issue that wrong RSSI values output.

-------------------------------------------------------------------------------------------------------------------
More details please check FrSky website:
https://www.frsky-rc.com/product/rxsr-fc-omnibus-f4-nano-v7/
https://www.frsky-rc.com/product/rxsr-fc-omninxt-f7/
https://www.frsky-rc.com/product/rxsr-fc-omnibus-f4-fireworks-v2/
https://www.frsky-rc.com/product/rxsr-fc-omnibus-f4-v6/
https://www.frsky-rc.com/frsky-advanced-communication-control-elevated-spread-spectrum-access-protocol-release/

**********************All rights reserved to FrSky Electronic ., Ltd.*********************************
 