
*******************************Release Note******************************************

This Package is for R9 MINI/R9MM Access firmware update. 

Version and Files: 
 
 R9MINI_LBT.frk                                                         Firmware under LBT mode which is certificated for CE rules. 
 R9MINI_FCC.frk                                                        Firmware under NonLbt mode which is certificated for FCC rules. 
 R9MINI_Flex.frk                                                        Firmware under Flex mode please check local rules before use it .
 readme.txt                                                                  Release note 
 
F.port / S.Port can be switched in the radio menu.

Firmware Version:1.2.0

The release firmware resolved the issues below:
--------------------------------------------------------------------------------------------------------------------
1. Fix bug with telemetry.
2. Optimize CRC check algorithm and improve error correction ability
.
3. Please update your module & receiver firmware accordingly.
--------------------------------------------------------------------------------------------------------------------

More details please check ACCESS introduction on FrSky website.
https://www.frsky-rc.com/frsky-advanced-communication-control-elevated-spread-spectrum-access-protocol-release/


**********************All rights reserved to FrSky Electronic ., Ltd.*********************************
