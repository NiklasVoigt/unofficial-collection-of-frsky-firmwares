
*******************************Release Note******************************************

This Package is for ACCESS v2.1.7 firmware update for RXSR-FC. 

Version and Files: 
RXSR-FC_ACCESS_2.1.7.frsk                          Upgrade file for RXSR-FC

readme.txt                                                         Release note 
 
Firmware Version: v2.1.7
The new updates of ACCESS 2.X.X not only fixed the known channel output error (uncontrolled servo movements) under certain conditions, but also optimized RF performance and added many useful features. It is highly recommended that all ACCESS customers upgrade to 2.X.X or later version of ISRM RF modules and receivers.

The released firmware changes are as below:
--------------------------------------------------------------------------------------------------------------------
Improved RF performance when working with the TANDEM module .
-------------------------------------------------------------------------------------------------------------------
More details please check FrSky website:
https://www.frsky-rc.com/product/rxsr-fc-omnibus-f4-nano-v7/
https://www.frsky-rc.com/product/rxsr-fc-omninxt-f7/
https://www.frsky-rc.com/product/rxsr-fc-omnibus-f4-fireworks-v2/
https://www.frsky-rc.com/product/rxsr-fc-omnibus-f4-v6/
https://www.frsky-rc.com/frsky-advanced-communication-control-elevated-spread-spectrum-access-protocol-release/

**********************All rights reserved to FrSky Electronic ., Ltd.*********************************
 