
*******************************Release Note******************************************

This Package is for R9 MINI/R9MM Access firmware update. Firmware under LBT mode will be released soon.

Version and Files: 
 
 R9_MINI_LBT.frk                                                         Firmware under LBT mode which is certificated for CE rules. F.Port / S.port can be chosed in radio menu.
 R9_MINI_R9MM_FCC/FCC_Fport.frk                          Firmware under NonLbt mode which is certificated for FCC rules. Fport version is Fport output supported. 
 R9_MINI_R9MM_Flex/Flex_Fport.frk                         Firmware under Flex mode please check local rules before use it .Fport version is Fport output supported. 
 readme.txt                                                                  Release note 
 
Firmware Version:1.1.1
 Date:20190614
 Update date :20190820,add LBT firmware.


The release firmware resolved the issues below:
--------------------------------------------------------------------------------------------------------------------
1. Add support for Access protocol which brings many new features and improves performance.

More details please check ACCESS introduction on FrSky website.
https://www.frsky-rc.com/frsky-advanced-communication-control-elevated-spread-spectrum-access-protocol-release/


**********************All rights reserved to FrSky Electronic ., Ltd.*********************************
