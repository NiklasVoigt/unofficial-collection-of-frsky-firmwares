
*******************************Release Note******************************************

This Package is for R9SX firmware update. 

Version and Files: 
R9SX_LBT.frsk                                 LBT (certificate for CE )Firmware for R9SX. 
R9SX_FCC.frsk                                Non-LBT (certificate for FCC )Firmware for R9SX. 
R9SX_FLEX.frsk                               FLEX Firmware(No certificate) for R9SX,please check local rules before use.

readme.txt                                         Release note 

F.port / S.Port can be switched in the radio menu.

Firmware Version: v1.3.3

The release firmware resolved the issues below:
--------------------------------------------------------------------------------------------------------------------
Fixed A2 port does not work for some R9SX receivers.
-------------------------------------------------------------------------------------------------------------------
How to update R9SX firmware :
1. Put the firmware under the folder [FIRMWARE] of sd card.
2. Register and bind the receiver with your radio, keep the receiver under working mode. 
3. Find the firmware in SD folder, select it by press [ENT].
4. Select Flash receiver OTA, re-cycle the receiver power and wait for flash ends.
5. Re-cycle the receiver power and wait for 3 seconds to have connection with your radio again.

Note: Receiver is still supported with flashing firmware by s.port connection to radio.
---------------------------------------------------------------------------------------------------------------------
More details please check FrSky website:
https://www.frsky-rc.com/product/r9-sx/

**********************All rights reserved to FrSky Electronic ., Ltd.*********************************
