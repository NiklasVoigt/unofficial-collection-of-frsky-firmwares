
*******************************Release Note******************************************

This Package is for TW R8 & TW GR8 firmware update. 

Version and Files: 
TW_R8_GR8_1.0.7.frsk                  Firmware for TW R8 & TW GR8 receiver.
readme.txt                                         

Release note 

Firmware Version: 【v1.0.7】
1. Fixed the issue of the communication range for the previous firmware version.
-------------------------------------------------------------------------------------------------------------------
Firmware Version: 【v1.0.6】
1. Improved the VFR capability and anti-interference performance.
Note: To work with this firmware update of the TW R8/GR8 receivers, please make sure the firmware of the TW-ISRM/TWIN Lite Pro RF module is upgraded to 1.0.5 or the latest version.
-------------------------------------------------------------------------------------------------------------------
Firmware Version: 【v1.0.5】
1. Fixed the RxBat telemetry issue that displayed voltage data with 6.52V only.
-------------------------------------------------------------------------------------------------------------------

How to update TWIN receiver firmware :
1. Put the firmware under the folder [FIRMWARE] of SD card.
2. Register and bind the receiver with your radio, keep the receiver under working mode. 
3. Find the firmware file in SD folder, select it by press [ENT].
4. Select Flash receiver OTA, re-cycle the receiver power and wait for flash ends.
5. Re-cycle the receiver power and wait for 3 seconds to have connection with your radio again.

Note: Receiver is still supported with flashing firmware by S.Port wire connection to a radio.
---------------------------------------------------------------------------------------------------------------------
More details please check FrSky website.
https://www.frsky-rc.com/product-category/receivers/dual-2-4ghz-tw/

**********************All rights reserved to FrSky Electronic ., Ltd.*********************************
