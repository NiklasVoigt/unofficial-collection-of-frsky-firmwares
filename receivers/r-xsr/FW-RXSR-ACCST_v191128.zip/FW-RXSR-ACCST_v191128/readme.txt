
*******************************Release Note******************************************

This Package is for ACCST firmware update for RXSR, F.PORT firmware included. 

Version and Files: 
RXSR_FCC_ACCST_191112.frk                            Firmware under NonLbt mode which is certificated for FCC rules.
RXSR_LBT_ACCST_191112.frk                             Firmware under LBT mode which is certificated for CE rules.
RXSR-FPORT_FCC_ACCST_191128.frk                F.PORT version firmware under NonLbt mode which is certificated for FCC rules.
RXSR-FPORT_LBT_ACCST_191128.frk                 F.PORT version firmware under LBT mode which is certificated for CE rules.
readme.txt                                                           Release note 
 
Firmware Version: v191112
F.Port Firmware Version:v191128

The release firmware resolved the issues below:
--------------------------------------------------------------------------------------------------------------------
-Fixed the problem of abnormal high frame loss rate.


More details please check the link below on FrSky website.
https://www.frsky-rc.com/product/r-xsr/

**********************All rights reserved to FrSky Electronic ., Ltd.*********************************