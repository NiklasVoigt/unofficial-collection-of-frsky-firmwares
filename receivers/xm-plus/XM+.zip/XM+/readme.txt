161118.frk and 161118_EU.frk are XM+ Non-EU and EU FW
161118-RSSI.frk and 161118_EU_RSSI.frk are XM+ Non-EU and EU FW with channel 16 outputs RSSI value (1000us~2000us) 