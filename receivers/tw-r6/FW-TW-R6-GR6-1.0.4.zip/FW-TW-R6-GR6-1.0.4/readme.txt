
*******************************Release Note******************************************

This Package is for TW R6 & TW GR6 firmware update. 

Version and Files: 
TW_R6_GR6_1.0.4.frsk                          Firmware for TW R6 & TW GR6 receiver.
readme.txt                                         Release note 


v1.0.4

1. For working compatibly with the TW-ISRM & TWIN Lite Pro RF modules with the V1.0.4 firmware and later version.
-------------------------------------------------------------------------------------------------------------------

How to update TWIN receiver firmware :
1. Put the firmware under the folder [FIRMWARE] of SD card.
2. Register and bind the receiver with your radio, keep the receiver under working mode. 
3. Find the firmware file in SD folder, select it by press [ENT].
4. Select Flash receiver OTA, re-cycle the receiver power and wait for flash ends.
5. Re-cycle the receiver power and wait for 3 seconds to have connection with your radio again.

Note: Receiver is still supported with flashing firmware by S.Port wire connection to a radio.
---------------------------------------------------------------------------------------------------------------------
More details please check FrSky website.
https://www.frsky-rc.com/product-category/receivers/dual-2-4ghz-tw/

**********************All rights reserved to FrSky Electronic ., Ltd.*********************************
