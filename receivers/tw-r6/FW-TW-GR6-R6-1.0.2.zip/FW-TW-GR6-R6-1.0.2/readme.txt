
*******************************Release Note******************************************

This Package is for TW GR6/R6 firmware update. 

Version and Files: 
TW-GR6-R6_1.0.2.frsk                          Firmware for TW GR6 & R6 receiver.
readme.txt                                         Release note 


v1.0.2

1. Add the Black-Box function.
-------------------------------------------------------------------------------------------------------------------

How to update TWIN receiver firmware :
1. Put the firmware under the folder [FIRMWARE] of SD card.
2. Register and bind the receiver with your radio, keep the receiver under working mode. 
3. Find the firmware file in SD folder, select it by press [ENT].
4. Select Flash receiver OTA, re-cycle the receiver power and wait for flash ends.
5. Re-cycle the receiver power and wait for 3 seconds to have connection with your radio again.

Note: Receiver is still supported with flashing firmware by s.port wire connection to a radio.
---------------------------------------------------------------------------------------------------------------------
More details please check FrSky website.
https://www.frsky-rc.com/product-category/receivers/dual-2-4ghz-tw/

**********************All rights reserved to FrSky Electronic ., Ltd.*********************************
