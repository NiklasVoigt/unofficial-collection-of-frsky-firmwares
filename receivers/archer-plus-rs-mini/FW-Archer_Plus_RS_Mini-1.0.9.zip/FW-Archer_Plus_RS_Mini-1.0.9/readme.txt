
*******************************Release Note******************************************

This package is for Archer Plus RS Mini firmware update. 

Version and Files: 
AP_RSmini_1.0.9.frsk                      Firmware for Archer Plus RS Mini receiver.
readme.txt                                         

Release note 

v1.0.9
The release firmware resolved the issues below:
--------------------------------------------------------------------------------------------------------------------
1. Fixed the issue of losing the telemetry after connecting the flight controller for running a short period.

v1.0.5
The release firmware resolved the issues below:
--------------------------------------------------------------------------------------------------------------------
1.Fixed the issue of telemetry cannot be received after repowering the receiver.
 
-------------------------------------------------------------------------------------------------------------------
How to update Archer Plus receiver firmware:
1. Put the firmware under the folder [FIRMWARE] of SD card.
2. Register and bind the receiver with your radio, keep the receiver under working mode. 
3. Find the firmware file in SD folder, select it by press [ENT].
4. Select Flash receiver OTA, re-cycle the receiver power and wait for flash ends.
5. Re-cycle the receiver power and wait for 3 seconds to have connection with your radio again.

Note: Receiver is still supported with flashing firmware by S.Port wire connection to a radio.
---------------------------------------------------------------------------------------------------------------------
More details please check FrSky website.
https://www.frsky-rc.com/product-category/receivers/2-4ghz-access/archer-plus-series/

**********************All rights reserved to FrSky Electronic ., Ltd.*********************************
