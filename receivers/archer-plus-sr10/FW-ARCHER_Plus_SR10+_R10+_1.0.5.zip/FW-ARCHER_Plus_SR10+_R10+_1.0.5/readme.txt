
*******************************Release Note******************************************

This Package is for Archer Plus SR10+ & R10+ firmware update. 

Version and Files: 
Archer-Plus_SR10+_R10+_1.0.5.frsk    Firmware for Archer Plus SR10+ & R10+ receiver.
readme.txt                                         Release note 


v1.0.5
1. Added the second group of stabilized 5 channels in ACCESS mode.
-------------------------------------------------------------------------------------------------------------------


How to update ACCESS receiver firmware:
1. Put the firmware under the folder [FIRMWARE] of SD card.
2. Register and bind the receiver with your radio, keep the receiver under working mode. 
3. Find the firmware file in SD folder, select it by press [ENT].
4. Select Flash receiver OTA, re-cycle the receiver power and wait for flash ends.
5. Re-cycle the receiver power and wait for 3 seconds to have connection with your radio again.

Note: The firmware upgrade for the receiver is still supported by wiring to the S.Port of the radio to complete.
---------------------------------------------------------------------------------------------------------------------
More details please check FrSky website.
https://www.frsky-rc.com/product-category/receivers/2-4ghz-access/archer-plus-series/

**********************All rights reserved to FrSky Electronic ., Ltd.*********************************
