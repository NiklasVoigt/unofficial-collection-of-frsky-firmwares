
*******************************Release Note******************************************

This Package is for Archer Plus SR10+ & R10+ firmware update. 

Version and Files: 
AP_SR10+_R10+_1.0.11.frsk    
Firmware for Archer Plus SR10+ & R10+ receiver.
Readme.txt                                         

Release Note
Firmware Version【v1.0.11】
Note: Please ensure you are using the latest V3.0.0 Lua scripts to configure the Stab device with flashed this firmware version. The older Stab Lua tools or the Stab tools in Device Config (ETHOS's integration) are not compatible.  

1. Added the Reset function to recover the Stab settings to the factory settings. 
2. Added the AUX mode option to each Stab channel.
3. Cancelled the operation requiring putting the Throttle stick to the lowest (＜1000us) while doing the Self-Check.
4. Added the Stick Priority function for Stab channels
Notice: Please Reset your stab device (by Lua tool) after flashing with this firmware version, and reconfigure it to make sure it can work properly. 
-------------------------------------------------------------------------------------------------------------------
Release Note【v1.0.10】
1. Fixed the compatible issue of the receiver working with the Stab Lua scripts running on some OPTX radio models (Taranis X9D Plus, etc.)
-------------------------------------------------------------------------------------------------------------------

Release Note【v1.0.9】
1. Added Pitch and Roll angle control for stabilization mode.(SR10+)
2. Fixed the telemetry error of the Pitch and Roll angle in the calibration process after repowering.(SR10+)
3. Fixed the issue that the Pitch angle sometimes fails in Hover mode. (SR10+)
4. Reduced the effect brought by vibrations for the stabilization function. (SR10+)
5. Fixed the issue of outputting a jitter signal while connecting or hot-swapping a redundant receiver by SBUS port.
-------------------------------------------------------------------------------------------------------------------

Release Note【v1.0.5】
1. Added the second group of stabilized 5 channels in ACCESS mode.
-------------------------------------------------------------------------------------------------------------------


How to update ACCESS receiver firmware:
1. Put the firmware under the folder [FIRMWARE] of SD card.
2. Register and bind the receiver with your radio, keep the receiver under working mode. 
3. Find the firmware file in SD folder, select it by press [ENT].
4. Select Flash receiver OTA, re-cycle the receiver power and wait for flash ends.
5. Re-cycle the receiver power and wait for 3 seconds to have connection with your radio again.

Note: The firmware upgrade for the receiver is still supported by wiring to the S.Port of the radio to complete.
---------------------------------------------------------------------------------------------------------------------
More details please check FrSky website.
https://www.frsky-rc.com/product-category/receivers/2-4ghz-access/archer-plus-series/

**********************All rights reserved to FrSky Electronic ., Ltd.*********************************
