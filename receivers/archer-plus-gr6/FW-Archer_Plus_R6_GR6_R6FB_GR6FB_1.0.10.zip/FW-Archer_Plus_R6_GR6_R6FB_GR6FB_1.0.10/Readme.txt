
*******************************Release Note******************************************

This Package is for Archer Plus R6 & GR6 & R6FB & GR6FB firmware update. 

Version and Files: AP_R6_GR6_R6FB_GR6FB_1.0.10.frsk     
- Firmware for Archer Plus R6 & GR6 & R6FB & GR6FB receiver.
- readme.txt                                         

Release note【v1.0.10】
1. Fixed the issue of outputting the ineffective signal by SBUS Out once powering the receiver on. 
-------------------------------------------------------------------------------------------------------------------

Release note【v1.0.5】
1.The first firmware for newly released products. 
-------------------------------------------------------------------------------------------------------------------


How to update ACCESS receiver firmware:
1. Put the firmware under the folder [FIRMWARE] of SD card.
2. Register and bind the receiver with your radio, keep the receiver under working mode. 
3. Find the firmware file in SD folder, select it by press [ENT].
4. Select Flash receiver OTA, re-cycle the receiver power and wait for flash ends.
5. Re-cycle the receiver power and wait for 3 seconds to have connection with your radio again.

Note: The firmware upgrade for the receiver is still supported by wiring to the S.Port of the radio to complete.
---------------------------------------------------------------------------------------------------------------------
More details please check FrSky website.
https://www.frsky-rc.com/product-category/receivers/2-4ghz-access/archer-plus-series/

**********************All rights reserved to FrSky Electronic ., Ltd.*********************************
