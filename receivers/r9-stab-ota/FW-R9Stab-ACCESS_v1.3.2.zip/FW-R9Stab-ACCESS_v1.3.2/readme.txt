
*******************************Release Note******************************************

This Package is for R9 STAB OTA ACCESS firmware update. 

Version and Files: 
 R9Stab_LBT.frsk                                            Firmware under LBT mode which is certificated for CE rules.  
 R9Stab_FCC.frsk                                           Firmware under NonLbt mode which is certificated for FCC rules. 
 R9Stab_FLEX.frsk                                          Firmware under Flex mode please check local rules before use it .
 readme.txt                                                  Release note 
 

Firmware Version: v1.3.2

The release firmware resolved the issues below:
--------------------------------------------------------------------------------------------------------------------
1. Enter the self-check mode through configuration, which facilitates operation and improves system security. 
Note: For ETHOS based radio only，please update the ETHOS to v1.1.2 or above to use .
2. Fix the output saturation problem caused by excessive vibration .
--------------------------------------------------------------------------------------------------------------------

More details please check the link below on FrSky website.
https://www.frsky-rc.com/frsky-access-r9-family-r9-stab-ota-long-range-and-stabilization-receiver-release/
https://www.frsky-rc.com/product/r9-stab-ota/


**********************All rights reserved to FrSky Electronic ., Ltd.*********************************