
*******************************Release Note******************************************

This Package is for R9 MINI/R9MM Access firmware update. 

Version and Files: 
 
 R9_MINI_LBT.frk                                                         Firmware under LBT mode which is certificated for CE rules. 
 R9_MINI_FCC.frk                                                        Firmware under NonLbt mode which is certificated for FCC rules. Fport version is Fport output supported. 
 R9_MINI_Flex.frk                                                        Firmware under Flex mode please check local rules before use it .Fport version is Fport output supported. 
 readme.txt                                                                  Release note 
 
Firmware Version:1.1.2

The release firmware resolved the issues below:
--------------------------------------------------------------------------------------------------------------------
1. F.port / S.Port can be switched in the radio menu.
2. FLEX and LBT(CE) / Non-LBT(FCC) firmware included.
3. Please upgrade module & radio firmware accordingly.

More details please check ACCESS introduction on FrSky website.
https://www.frsky-rc.com/frsky-advanced-communication-control-elevated-spread-spectrum-access-protocol-release/


**********************All rights reserved to FrSky Electronic ., Ltd.*********************************
