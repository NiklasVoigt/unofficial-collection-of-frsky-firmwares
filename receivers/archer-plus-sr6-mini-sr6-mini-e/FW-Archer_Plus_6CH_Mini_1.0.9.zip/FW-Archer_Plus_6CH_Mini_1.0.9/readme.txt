
*******************************Release Note******************************************

This Package is for Archer Plus R6Mini | R6Mini-E | SR6Mini | SR6Mini-E firmware update. 

Version and Files: AP_6CH_Mini_1.0.9.frsk     
- Firmware for Archer Plus R6Mini | R6Mini-E | SR6Mini | SR6Mini-E receivers.
- readme.txt                                         

Release note (v1.0.9)
-------------------------------------------------------------------------------------------------------------------
1. The first firmware for newly released products.
-------------------------------------------------------------------------------------------------------------------


How to update ACCESS receiver firmware:
1. Put the firmware under the folder [FIRMWARE] of SD card.
2. Register and bind the receiver with your radio, keep the receiver under working mode. 
3. Find the firmware file in SD folder, select it by press [ENT].
4. Select Flash receiver OTA, re-cycle the receiver power and wait for flash ends.
5. Re-cycle the receiver power and wait for 3 seconds to have connection with your radio again.

Note: The firmware upgrade for the receiver is still supported by wiring to the S.Port of the radio to complete.
---------------------------------------------------------------------------------------------------------------------
More details please check FrSky website.
https://www.frsky-rc.com/product-category/receivers/2-4ghz-access/archer-plus-series/

**********************All rights reserved to FrSky Electronic ., Ltd.*********************************
