
*******************************Release Note******************************************

This Package is for receiver TDSR6 firmware update. 

Version and Files: 
TDSR6_1.0.11.frsk                            Upgrade file for the receiver TDSR6.


readme.txt                                                         

Release Note 
Firmware Version: 【v1.0.11】
1.The first firmware for newly released products. 
-------------------------------------------------------------------------------------------------------------------

Note: Please update the firmware of all your radios with TD module and receivers accordingly.
-------------------------------------------------------------------------------------------------------------------
How to update internal module TD ISRM:
By radio (SD card) :
1. Put the firmware under the folder [FIRMWARE] of sd card.
2. Power on the radio and find the firmware,select it by press [ENT].
3. Select 'Flash int. module', wait to end.

How to update Tandem receiver by OTA(Over The Air):
1. For ETHOS radios, go to the [File manager], and select the FW
2. Press the enter button, select [Flash RX by int.OTA].
3. Power on the receiver, select the RX, go to the [ENTER], complete the flash process
4. The transmitter will display [Success]. 
5. Wait for 3 seconds,the receiver works properly at the moment.

---------------------------------------------------------------------------------------------------------------------
More details please check FrSky website:
https://www.frsky-rc.com/product-category/receivers/2-4ghz900mhz-td/

**********************All rights reserved to FrSky Electronic ., Ltd.*********************************
 