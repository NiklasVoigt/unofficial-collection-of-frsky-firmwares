
*******************************Release Note******************************************

This Package is for S6R/S8R firmware update .FCC and LBT firmwares are included.
LBT firmware is under Europe Union LBT(Listen before talk) mode and FCC is compliance to FCC rules which under NonLBT mode.

Version: v20190531
Files:

 S6R\S6R_FCC_20190531.frk               firmware for S6R under NonLBT mode
 S6R\S6R_LBT_20190531.frk               firmware for S6R under LBT mode
 S8R\S8R_FCC_20190531.frk               firmware for S8R under NonLBT mode
 S8R\S8R_LBT_20190531.frk               firmware for S8R under LBT mode

The release resolved the issues below:
--------------------------------------------------------------------------------------------------------------------
1. Fix the issue that for some of the Rx No. ,binding is not possible.
2. Optimised the lua support when using SxR to set other devices like sensors,esc .etc.

---------------------------------------------------------------------------------------------------------------------------------
How to upgrade SxR receivers please refer to the videos below:

With X9DP:
https://www.frsky-rc.com/how-to-use-the-transmitter-to-flash-the-firmware-of-the-x8r-receiver/
*For other radios which have s.port please choose [Flash s.port] in menu .

With Airlink S :
https://www.frsky-rc.com/how-to-upgrade-the-s-series-receivers-with-the-s-port-airlink-s/

With STK:
https://www.frsky-rc.com/how-to-use-frsky-stk-tool-to-update-firmware/

More information about SxR please refer to manual on FrSky website. 

**********************All rights reserved to FrSky Electronic ., Ltd.*********************************



