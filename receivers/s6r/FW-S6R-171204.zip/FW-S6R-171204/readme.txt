Fix the bug that compensate is not correct in VTAIL mode.
