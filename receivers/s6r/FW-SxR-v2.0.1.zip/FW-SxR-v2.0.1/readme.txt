
*******************************Release Note******************************************

This Package is for S6R/S8R firmware update .FCC and LBT firmwares are included.
LBT firmware is under Europe Union LBT(Listen before talk) mode and FCC is compliance to FCC rules which under NonLBT mode.

Version: v2.0.1
Files:

 S6R\S6R_ACCST_V2.0.1_FCC.frk.frk               firmware for S6R under NonLBT mode
 S6R\S6R_ACCST_V2.0.1_FCC.frk.frk               firmware for S6R under LBT mode
 S8R\S8R_ACCST_V2.0.1_FCC.frk                    firmware for S8R under NonLBT mode
 S8R\S8R_ACCST_V2.0.1_FCC.frk                    firmware for S8R under LBT mode

ACCST D16 2.0.0 - This upgrade is designed to enhance the reliability and performance of radio transmission in all external conditions. It is strongly recommended that all FCC/LBT users update all their equipment to version 2.0.0. This includes all radios, RF modules and receivers.

We are grateful to you all for supporting FrSky. Especially thank those who reported the issue, provided the information, and assisted with many tests. 
The release resolved the issues below:
--------------------------------------------------------------------------------------------------------------------
1.Fixed the channel output error (uncontrolled servo movements) under certain conditions.
2.Strengthened correction and verification capability.
Note: Please update the firmware of all your radios, RF modules and receivers accordingly.

---------------------------------------------------------------------------------------------------------------------------------
How to upgrade receivers please refer to the info below:
With X9DP:
https://www.frsky-rc.com/how-to-use-the-transmitter-to-flash-the-firmware-of-the-x8r-receiver/

With other radios which have s.port please choose [Flash s.port] in menu .
1. Put the firmware under the folder [FIRMWARE] of sd card.
2. Power on the radio and find the firmware,select it by press [ENT].
3. Select 'Flash S.port ', wait to end.

With Airlink S :
https://www.frsky-rc.com/how-to-upgrade-the-s-series-receivers-with-the-s-port-airlink-s/

With STK:
https://www.frsky-rc.com/how-to-use-frsky-stk-tool-to-update-firmware/
---------------------------------------------------------------------------------------------------------------------
More information about SxR please refer to manual on FrSky website. 
https://www.frsky-rc.com/product/s6r/
https://www.frsky-rc.com/product/s8r/

**********************All rights reserved to FrSky Electronic ., Ltd.*********************************



