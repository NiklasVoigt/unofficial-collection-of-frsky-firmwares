
*******************************Release Note******************************************

This Package is for R9 Slim/R9 Slim+ Access firmware update. 

Version and Files: 
 R9Slim_LBT.frk                                            Firmware under LBT mode which is certificated for CE rules.  
 R9Slim_FCC.frk                                           Firmware under NonLbt mode which is certificated for FCC rules. 
 R9Slim_FLEX.frk                                           Firmware under Flex mode please check local rules before use it .
 readme.txt                                                  Release note 
 

Firmware Version:1.3.0

The release firmware resolved the issues below:
--------------------------------------------------------------------------------------------------------------------
1. Improved RF performance.
2. Added the telemetry for LFR (Lost Frame Rate).
3. Added the telemetry for the power value in self-power adaptive mode.
-----------------------------------------------------------------------------------------------------------------------

More details please check ACCESS introduction on FrSky website.
https://www.frsky-rc.com/frsky-advanced-communication-control-elevated-spread-spectrum-access-protocol-release/


**********************All rights reserved to FrSky Electronic ., Ltd.*********************************