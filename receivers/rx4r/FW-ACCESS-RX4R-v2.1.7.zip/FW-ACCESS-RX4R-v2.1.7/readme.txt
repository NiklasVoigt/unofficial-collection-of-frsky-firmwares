
*******************************Release Note******************************************

This Package is for Receivers ACCESS v2.1.7 firmware update. 
Version and Files: 

RX4R_ACCESS_v2.1.7.frsk                                 Upgrade file for RX4R

readme.txt                                              Release note 
 
Firmware Version: v2.1.7

The new updates of ACCESS 2.X.X not only fixed the known channel output error (uncontrolled servo movements) under certain conditions, but also optimized RF performance and added many useful features. It is highly recommended that all ACCESS customers upgrade to 2.X.X or later version of ISRM RF modules and receivers.

The released firmware changes are as below:
--------------------------------------------------------------------------------------------------------------------
1. Resolved the issue of that RXSR not starting properly when working with RXSR(RXSR as slave receiver) in redundancy mode .
2. Improved RF performance when working with the TANDEM module .
-------------------------------------------------------------------------------------------------------------------
How to update receiver firmware :
https://www.frsky-rc.com/how-to-use-the-transmitter-to-flash-the-firmware-of-the-x8r-receiver/

-------------------------------------------------------------------------------------------------------------------
More details please check FrSky website:
https://www.frsky-rc.com/frsky-advanced-communication-control-elevated-spread-spectrum-access-protocol-release/
https://www.frsky-rc.com/product/rx4r/
https://www.frsky-rc.com/product/rx6r/

**********************All rights reserved to FrSky Electronic ., Ltd.*********************************
 