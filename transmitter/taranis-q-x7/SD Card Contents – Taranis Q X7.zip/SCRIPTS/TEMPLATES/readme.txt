This directory is for template lua scripts.
