This directory is for lua mixer scripts.
