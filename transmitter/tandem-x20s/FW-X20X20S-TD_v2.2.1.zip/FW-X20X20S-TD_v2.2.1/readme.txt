
*******************************Release Note******************************************

This Package is for X20/X20S TD module v2.2.1 firmware update. 

Version and Files: 
TD_2.2.1.frsk                            Upgrade file for the upgrade TD module for X20/X20S.


readme.txt                                                         Release note 
 
Firmware Version: v2.2.1

The new updates of ACCESS 2.X.X not only fixed the known channel output error (uncontrolled servo movements) under certain conditions, but also optimized RF performance and added many useful features. It is highly recommended that all ACCESS customers upgrade to 2.X.X or later version of ISRM RF modules and receivers.

The released firmware changes are as below:
--------------------------------------------------------------------------------------------------------------------
1. Fix telemetry being sometimes unstable in TD mode.
2. Fix the abnormal 900M power output after switching between ACCST/ACCESS/TD modes.
---------------------------------------------------------------------------------------------------------------------

Compatibility
                                            |       TD Modules & TANDEM Radios
                                            |                            v2.1.x
--------------------------------------------------------------------------------------
Rx ACCESS 2.X.X	            |                      YES
Rx ACCST D16 2.1.X            |                      YES
Rx ACCESS 1.X	            |                      NO
Rx ACCST D16 2.0.1            |                      NO
Rx ACCST History	            |                      NO

Note: Please update the firmware of all your radios, RF modules and receivers accordingly.
-------------------------------------------------------------------------------------------------------------------
How to update internal module TD ISRM:
By radio (SD card) :
1. Put the firmware under the folder [FIRMWARE] of sd card.
2. Power on the radio and find the firmware,select it by press [ENT].
3. Select 'Flash int. module', wait to end.
---------------------------------------------------------------------------------------------------------------------
More details please check FrSky website:
https://www.frsky-rc.com/product/tandem-x20/
https://www.frsky-rc.com/product/tandem-x20s/

**********************All rights reserved to FrSky Electronic ., Ltd.*********************************
 