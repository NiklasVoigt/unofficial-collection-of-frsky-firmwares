
*******************************Release Note******************************************

This Package is for X9 lite firmware update. 

Version and Files: 
 firmware_x9lite_190720.bin / .dfu                     Firmware for X9 lite. 
 readme.txt                                                           Release note 
 
Firmware Version: OpenTX v2.3.0
Date:20190720
SD contents Version  :  2.3v0019

The release firmware resolved the issues below:
--------------------------------------------------------------------------------------------------------------------
1. Perfectly support R9M Lite and R9M Lite Pro modules on both ACCESS and ACCST modes .

2. Fix the bug that encoder has chance to fail.

-------------------------------------------------------------------------------------------------------------------
How to update radio firmware(take x9dp as example) :
By SD card:
https://www.frsky-rc.com/wp-content/uploads/2017/07/How%20to/How-to%20For%20Upgrading%20TARANIS%20Plus.pdf
https://www.frsky-rc.com/how-to-flash-the-firmware-of-the-x9d-plus-with-the-miniusb-wire/
By companion software:
https://www.frsky-rc.com/how-to-use-companion-to-flash-the-firmware-of-x9d-plus/

---------------------------------------------------------------------------------------------------------------------
More details please check FrSky website:
https://www.frsky-rc.com/product/taranis-x9-lite/

**********************All rights reserved to FrSky Electronic ., Ltd.*********************************
