
*******************************Release Note******************************************

This Package is for X-Lite S/Pro / X9 lite firmware update. 

Version and Files: 
 firmware_xlites_pro_190626.bin / .dfu              Firmware X-Lite S/Pro .
 firmware_x9lite_190626.bin / .dfu                     Firmware for X9 lite. 
 readme.txt                                                           Release note 
 
Firmware Version: OpenTX v2.3.0
Date:20190626
SD contents Version  :  2.3v0019

The release firmware resolved the issues below:
--------------------------------------------------------------------------------------------------------------------
1. Add the support of R9M Lite module (ACCESS) .

2. Support update OTA ( Over The Air )function.

3. Fix the bugs about radios sometimes cannot totally power down.

4. Optimize the PARA wireless module connection.
5. Improve the process for PMU update.
5. Improve the process for PMU update.

-------------------------------------------------------------------------------------------------------------------
How to update radio firmware(take x9dp as example) :
By SD card:
https://www.frsky-rc.com/wp-content/uploads/2017/07/How%20to/How-to%20For%20Upgrading%20TARANIS%20Plus.pdf
https://www.frsky-rc.com/how-to-flash-the-firmware-of-the-x9d-plus-with-the-miniusb-wire/
By companion software:
https://www.frsky-rc.com/how-to-use-companion-to-flash-the-firmware-of-x9d-plus/

---------------------------------------------------------------------------------------------------------------------
PMU update procedure:
1. Copy the autoupdate.frsk file to the FIRMWARE folder in SD card .
2. Power on your radio and you will have the PMU updating .
3. Wait for success and you will have a pop up with messages of success or failure.
4. The autoupdate.frsk file will be removed by system after success.

*Please ONLY do updates when you have the issues about external module (behavior description: the module may power down after about 8 seconds of normally working).
*Please DONOT do PMU update again if you have already succeeded in updating it before.

--------------------------------------------------------------------------------------------------------------------
More details please check FrSky website:
https://www.frsky-rc.com/product/taranis-x-lite-pro/
https://www.frsky-rc.com/product/taranis-x-lite-s/
https://www.frsky-rc.com/product/taranis-x9-lite/

**********************All rights reserved to FrSky Electronic ., Ltd.*********************************
