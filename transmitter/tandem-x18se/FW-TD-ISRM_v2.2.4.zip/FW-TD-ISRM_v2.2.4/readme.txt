
*******************************Release Note******************************************

This Package is for TD-ISRM module of TANDEM radios v2.2.4 firmware update. 

Version and Files: 
TD-ISRM_2.2.4.frsk                            Upgrade file for the upgrade TD-ISRM module for TANDEM X18/X18S/X18SE/X20/X20S/X20HD/XE.


readme.txt                                                         Release note 
 
Firmware Version: v2.2.4


The released firmware changes are as below:
--------------------------------------------------------------------------------------------------------------------
1. Add the support for TANDEM XE radio.

---------------------------------------------------------------------------------------------------------------------

Compatibility
                                            |       TD-ISRM Modules & TANDEM Radios
                                            |                            v2.2.x
--------------------------------------------------------------------------------------
Rx ACCESS 2.X.X	            |                      YES
Rx ACCST D16 2.1.X              |                      YES
Rx ACCESS 1.X	            |                      NO
Rx ACCST D16 2.0.1              |                      NO
Rx ACCST History	            |                      NO

Note1: Please update the firmware of all your radios, RF modules and receivers accordingly.
Note2: The new updates of ACCESS 2.X.X not only fixed the known channel output error (uncontrolled servo movements) under certain conditions, but also optimized RF performance and added many useful features. It is highly recommended that all ACCESS customers upgrade to 2.X.X or later version of ISRM RF modules and receivers.
-------------------------------------------------------------------------------------------------------------------
How to update internal module TD ISRM:
By radio (SD card) :
1. Put the firmware under the folder [FIRMWARE] of sd card.
2. Power on the radio and find the firmware,select it by press [ENT].
3. Select 'Flash int. module', wait to end.
---------------------------------------------------------------------------------------------------------------------
More details please check FrSky website:
https://www.frsky-rc.com/tandem-x18/
https://www.frsky-rc.com/tandem-x18s/
https://www.frsky-rc.com/tandem-x18se/
https://www.frsky-rc.com/tandem-x20/
https://www.frsky-rc.com/tandem-x20s/
https://www.frsky-rc.com/tandem-x20-hd/
https://www.frsky-rc.com/tandem-xe/

**********************All rights reserved to FrSky Electronic ., Ltd.*********************************
 