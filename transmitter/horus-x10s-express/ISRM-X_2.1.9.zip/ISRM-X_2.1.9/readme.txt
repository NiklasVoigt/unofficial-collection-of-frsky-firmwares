
*******************************Release Note******************************************

This Package is for ISRM module v2.1.9 firmware update. 

Version and Files: 
ISRM-X_2.1.9.frsk                            Upgrade file for ISRM RF module 


readme.txt                                                         Release note 
 
Firmware Version: v2.1.9


The released firmware changes are as below:
--------------------------------------------------------------------------------------------------------------------
1. Fixed the issue of no PWM output caused by abnormal conditions such as specific false data or exceeding the limitation of devices connected in the S.Port link (>27 units).

Note: Please make sure the involved Receiver [Archer series (except for RS), R-XSR, RXSR-FC, RX4R, RX6R, G-RX6, G-RX8] or Transmitter [ISRM-N, ISRM-Pro, ISRM-S series RF module] in using have been both upgraded with this update or later version.

---------------------------------------------------------------------------------------


Compatibility                     |       ISRM Modules & ACCESS Radios
--------------------------------------------------------------------------------------
ISRM-N → (Taranis X9 Lite & QX7 ACCESS & QX7S ACCESS)
ISRM-S-X9LITES → (Taranis X9 Lite S)
ISRM-S-X9DP2019 → (Taranis X9DP 2019 & X9DP 2019 SE)
ISRM-S-XLITES → (Taranis XLite S)
ISRM-Pro → (Taranis XLite Pro)
ISRM-S-X10E → (Horus X10 EXPRESS & X10S EXPRESS)
ISRM-S-X10S → (ACCESS Upgrade Module)


Note: Please update the firmware of all RF modules and receivers accordingly.
-------------------------------------------------------------------------------------------------------------------
How to update internal module ISRM:
By radio (SD card) :
1. Put the firmware under the folder [FIRMWARE] of sd card.
2. Power on the radio and find the firmware,select it by press [ENT].
3. Select 'Flash int. module', wait to end.
---------------------------------------------------------------------------------------------------------------------


**********************All rights reserved to FrSky Electronic ., Ltd.*********************************
 