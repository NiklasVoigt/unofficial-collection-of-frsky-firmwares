Firmware-Taranis X9D Plus

Compatibility: Taranis X9D Plus
UpdateTime: 2014-10-10
Version: opentx-x9dp-v2.0.9

notes:
PXX output signal bug fixed
