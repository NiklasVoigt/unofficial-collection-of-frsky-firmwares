
*******************************Release Note******************************************

This Package is for X-lite Pro/S and the ISRM module,PMU(Power Management Unit)  are included.

Version and Files: 
 Opentx v2.2.3 190605               firmware_xlite-pro-s_190605.bin for X-Lite Pro 
 ISRM v1.1.2 190604                   ISRM_PRO_190604.frk for X-Lite Pro
 PMU v1.0                                   PMU.frsk for X-Lite Pro

The release firmware resolved the issues below:
--------------------------------------------------------------------------------------------------------------------
1. Fix the power management unit issue for external module.
2. Add the support of R9M Lite module (ACCST) .
3. Add the support of D16 mode for ISRM.
4. Fix other small bugs.
----------------------------------------------------------------------------------------------------------------------
Please take care of the tips below:
1. Procedure to update the PMU(Power Management Unit) :
  *Put the PMU.frsk file under [FIRMWARE] folder of SD card;
  *Power on radio and select the PMU.frsk.
  *Long press of the [ENT] and select update ;
  *Waiting for finish of updating.
2. D16 and ACCESS of ISRM will share the same region mode of LBT or NonLBT so, radio will be upgraded to support D16 under the same region mode of your radio.
3. R9M Lite ACCSESS and R9M Lite Pro will be released soon, you can find the menu in the external module menu.

**********************All rights reserved to FrSky Electronic ., Ltd.*********************************

