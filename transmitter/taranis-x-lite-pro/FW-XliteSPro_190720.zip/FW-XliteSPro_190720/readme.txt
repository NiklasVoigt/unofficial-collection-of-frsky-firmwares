
*******************************Release Note******************************************

This Package is for X-lite S/Pro firmware update. 

Version and Files: 
 firmware_xlites_pro_190720.bin / .dfu                     Firmware for X-lite S/Pro. 
 readme.txt                                                           Release note 
 
Firmware Version: OpenTX v2.3.0
Date: 20190720
SD contents Version  :  2.3v0019

The release firmware resolved the issues below:
--------------------------------------------------------------------------------------------------------------------
1. Perfectly support R9M Lite and R9M Lite Pro modules on both ACCESS and ACCST modes .


-------------------------------------------------------------------------------------------------------------------
How to update radio firmware(take x9dp as example) :
By SD card:
https://www.frsky-rc.com/wp-content/uploads/2017/07/How%20to/How-to%20For%20Upgrading%20TARANIS%20Plus.pdf
https://www.frsky-rc.com/how-to-flash-the-firmware-of-the-x9d-plus-with-the-miniusb-wire/
By companion software:
https://www.frsky-rc.com/how-to-use-companion-to-flash-the-firmware-of-x9d-plus/

---------------------------------------------------------------------------------------------------------------------
More details please check FrSky website:
https://www.frsky-rc.com/product/taranis-x-lite-pro/
https://www.frsky-rc.com/product/taranis-x-lite-s/

**********************All rights reserved to FrSky Electronic ., Ltd.*********************************
