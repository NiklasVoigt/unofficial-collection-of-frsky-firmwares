
*******************************Release Note******************************************

This Package is for TW-ISRM module of TWIN radios v1.0.2 firmware update. 

Version and Files: 
TW-ISRM_1.0.2.frsk                            Upgrade file for the upgrade TW-ISRM module for TWIN XLite/XLite S.


readme.txt                                                         Release note 
 
Firmware Version: v1.0.2

The released firmware changes are as below:
--------------------------------------------------------------------------------------------------------------------
1. Fixed the telemetry issue of alarming at the short range.

---------------------------------------------------------------------------------------------------------------------

How to update internal module TW-ISRM:
By radio (SD card) :
1. Put the firmware under the folder [FIRMWARE] of sd card.
2. Power on the radio and find the firmware,select it by press [ENT].
3. Select 'Flash int. module', wait to end.
---------------------------------------------------------------------------------------------------------------------

**********************All rights reserved to FrSky Electronic ., Ltd.*********************************
 