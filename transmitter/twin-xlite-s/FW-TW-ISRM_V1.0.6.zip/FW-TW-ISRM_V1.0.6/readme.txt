
*******************************Release Note******************************************

This Package is for TW-ISRM module of TWIN radios v1.0.6 firmware update. 

Version and Files: 
TW-ISRM_1.0.6.frsk                            
Upgrade file for the upgrade TW-ISRM module for TWIN XLite/XLite S/X14/X14S/V20.


readme.txt                                                         

Release note 
Firmware Version: 【v1.0.6】
1. Added the support of configuration capability for the RemoteNFC's features. 
2. Added the hardware compatibility of Kavan V20 radio.
---------------------------------------------------------------------------------------------------------------------

Firmware Version: 【v1.0.5】
1. Improved the VFR capability and anti-interference performance.
2. Improved real-time transmission performance of failsafe data.
Note: To work with this firmware update of the Twin XLite series radios, please make sure the firmware of the TW series receiver is upgraded to 1.0.5/1.0.6 or the latest version.
---------------------------------------------------------------------------------------------------------------------

Firmware Version: 【v1.0.4】
1. Added support for working with TW R8 and TW GR8 receivers.
Note: To work compatible with this firmware update of the TW-ISRM module, please make sure the firmware of the TW series receiver is upgraded to 1.0.4 or a later version. 
---------------------------------------------------------------------------------------------------------------------

How to update internal module TW-ISRM:
By radio (SD card) :
1. Put the firmware under the folder [FIRMWARE] of sd card.
2. Power on the radio and find the firmware,select it by press [ENT].
3. Select 'Flash int. module', wait to end.
---------------------------------------------------------------------------------------------------------------------

**********************All rights reserved to FrSky Electronic ., Ltd.*********************************
 