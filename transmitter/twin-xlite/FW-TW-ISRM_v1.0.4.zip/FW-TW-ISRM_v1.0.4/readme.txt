
*******************************Release Note******************************************

This Package is for TW-ISRM module of TWIN radios v1.0.4 firmware update. 

Version and Files: 
TW-ISRM_1.0.4.frsk                            Upgrade file for the upgrade TW-ISRM module for TWIN XLite/XLite S.


readme.txt                                                         Release note 
 
Firmware Version: v1.0.4

The released firmware changes are as below:
--------------------------------------------------------------------------------------------------------------------
1. Added support for working with TW R8 and TW GR8 receivers.
Note: To work compatible with this firmware update of the TW-ISRM module, please make sure the firmware of the TW series receiver is upgraded to 1.0.4 or a later version. 

---------------------------------------------------------------------------------------------------------------------

How to update internal module TW-ISRM:
By radio (SD card) :
1. Put the firmware under the folder [FIRMWARE] of sd card.
2. Power on the radio and find the firmware,select it by press [ENT].
3. Select 'Flash int. module', wait to end.
---------------------------------------------------------------------------------------------------------------------

**********************All rights reserved to FrSky Electronic ., Ltd.*********************************
 