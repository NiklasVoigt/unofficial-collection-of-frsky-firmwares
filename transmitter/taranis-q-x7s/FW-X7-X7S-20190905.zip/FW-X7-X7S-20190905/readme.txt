
*******************************Release Note******************************************

This Package is for Taranis Q X7/ Q X7S firmware update. 

Version and Files: 
 firmware_x7_fcc/lbt_190905.bin / .dfu                     Firmware for Taranis QX7 / QX7S. 
 readme.txt                                                                  Release note 
 
Firmware Version: OpenTX v2.3.0
Date: 20190905
SD contents Version  :  2.3v0020

The release firmware resolved the issues below:
--------------------------------------------------------------------------------------------------------------------
1. Fix the issue about LED flashing when powering on .

2. Update to opentx v2.3.0.

-------------------------------------------------------------------------------------------------------------------
How to update radio firmware(take x9dp as example) :
By SD card:
https://www.frsky-rc.com/wp-content/uploads/2017/07/How%20to/How-to%20For%20Upgrading%20TARANIS%20Plus.pdf
https://www.frsky-rc.com/how-to-flash-the-firmware-of-the-x9d-plus-with-the-miniusb-wire/
By companion software:
https://www.frsky-rc.com/how-to-use-companion-to-flash-the-firmware-of-x9d-plus/

---------------------------------------------------------------------------------------------------------------------
More details please check FrSky website:
https://www.frsky-rc.com/product/taranis-q-x7-2/
https://www.frsky-rc.com/product/taranis-q-x7s/

**********************All rights reserved to FrSky Electronic ., Ltd.*********************************
