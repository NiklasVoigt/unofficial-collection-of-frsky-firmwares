
*******************************Release Note******************************************

This Package is for TD module of TANDEM radios v2.2.2 firmware update. 

Version and Files: 
TD_2.2.2.frsk                            Upgrade file for the upgrade TD module for X18/X18S/X20/X20S/X20HD.


readme.txt                                                         Release note 
 
Firmware Version: v2.2.2

The new updates of ACCESS 2.X.X not only fixed the known channel output error (uncontrolled servo movements) under certain conditions, but also optimized RF performance and added many useful features. It is highly recommended that all ACCESS customers upgrade to 2.X.X or later version of ISRM RF modules and receivers.

The released firmware changes are as below:
--------------------------------------------------------------------------------------------------------------------
1. Fix the issue that FC cannot be set to 125/126 through the LUA script.
2. Fix the issue that offset values -2/-3 for SRX/SXR  cannot be saved.
3. Fix the issue that telemetry cannot display sometimes after the RF mode is switched over.
---------------------------------------------------------------------------------------------------------------------

Compatibility
                                            |       TD Modules & TANDEM Radios
                                            |                            v2.1.x
--------------------------------------------------------------------------------------
Rx ACCESS 2.X.X	            |                      YES
Rx ACCST D16 2.1.X            |                      YES
Rx ACCESS 1.X	            |                      NO
Rx ACCST D16 2.0.1            |                      NO
Rx ACCST History	            |                      NO

Note: Please update the firmware of all your radios, RF modules and receivers accordingly.
-------------------------------------------------------------------------------------------------------------------
How to update internal module TD ISRM:
By radio (SD card) :
1. Put the firmware under the folder [FIRMWARE] of sd card.
2. Power on the radio and find the firmware,select it by press [ENT].
3. Select 'Flash int. module', wait to end.
---------------------------------------------------------------------------------------------------------------------
More details please check FrSky website:
https://www.frsky-rc.com/tandem-x18/
https://www.frsky-rc.com/tandem-x18s/
https://www.frsky-rc.com/product/tandem-x20/
https://www.frsky-rc.com/product/tandem-x20s/
https://www.frsky-rc.com/tandem-x20-hd/

**********************All rights reserved to FrSky Electronic ., Ltd.*********************************
 