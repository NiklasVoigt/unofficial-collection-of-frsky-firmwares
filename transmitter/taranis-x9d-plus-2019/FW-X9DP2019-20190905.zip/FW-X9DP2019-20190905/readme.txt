
*******************************Release Note******************************************

This Package is for Taranis X9DP/SE 2019 firmware update. 

Version and Files: 
 firmware_x9dp2019_en_190905.bin / .dfu                     Firmware for Taranis X9DP/SE 2019. 
 readme.txt                                                                       Release note 
 
Firmware Version: OpenTX v2.3.0
Date: 20190905
SD contents Version  :  2.3v0020

The release firmware resolved the issues below:
--------------------------------------------------------------------------------------------------------------------
1. Support R9M 2019 ACCESS .


-------------------------------------------------------------------------------------------------------------------
How to update radio firmware(take x9dp as example) :
By SD card:
https://www.frsky-rc.com/wp-content/uploads/2017/07/How%20to/How-to%20For%20Upgrading%20TARANIS%20Plus.pdf
https://www.frsky-rc.com/how-to-flash-the-firmware-of-the-x9d-plus-with-the-miniusb-wire/
By companion software:
https://www.frsky-rc.com/how-to-use-companion-to-flash-the-firmware-of-x9d-plus/

---------------------------------------------------------------------------------------------------------------------
More details please check FrSky website:
https://www.frsky-rc.com/product/taranis-x9d-plus-2019/
https://www.frsky-rc.com/product/taranis-x9d-plus-se-2019/

**********************All rights reserved to FrSky Electronic ., Ltd.*********************************
