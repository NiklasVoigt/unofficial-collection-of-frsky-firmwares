readme
1. fix the issue of wrong channel output when channel speed is changed
2. fix the issue of celsMin data display
3. fix the issue about logic sw
4. fix the issue of thr cut