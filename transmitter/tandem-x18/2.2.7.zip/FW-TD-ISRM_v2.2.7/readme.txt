
*******************************Release Note******************************************

This Package is for TD-ISRM module of TANDEM radios v2.2.7 firmware update. 

Version and Files: 
TD-ISRM_2.2.7.frsk 
Upgrade file for the upgrade TD-ISRM module for TANDEM X18/X18S/X18SE/X20/X20S/X20HD/XE.
readme.txt                                                         


Release note 
Firmware Version【v2.2.7】
--------------------------------------------------------------------------------------------------------------------
1. Fixed the issue of the RF power (in self-adaptive mode) being maintained at the last output power after losing the telemetry data of the receiver. 
2. Fixed the issue of the repeat telemetry data of the same sensor source.

Firmware Version【v2.2.6】
--------------------------------------------------------------------------------------------------------------------
1. Fixed the issue that the model with 2.4G ACCST mode failed to work after switching from the model set with other protocols. 
2. Fixed the issue of RSSI alarms while staying in the Info menu.
3. Improved the switching speed of telemetry between RX1/RX2/RX3 in TD mode.
4. Added the support of telemetry data transmission through 2.4G links in the TD mode (The telemetry via 2.4G links can be also achieved under sufficient range with the RF power settings above 25mW in EU mode). 
Note: Please ensure the firmware of TD receivers is updated to the latest version. 

Firmware Version【v2.2.4】
--------------------------------------------------------------------------------------------------------------------
1. Add the support for TANDEM XE radio.





---------------------------------------------------------------------------------------------------------------------

Compatibility
                                            |       TD-ISRM Modules & TANDEM Radios
                                            |                            v2.2.x
--------------------------------------------------------------------------------------
Rx ACCESS 2.X.X	            |                      YES
Rx ACCST D16 2.1.X              |                      YES
Rx ACCESS 1.X	            |                      NO
Rx ACCST D16 2.0.1              |                      NO
Rx ACCST History	            |                      NO

Note1: Please update the firmware of all your radios, RF modules and receivers accordingly.
Note2: The new updates of ACCESS 2.X.X not only fixed the known channel output error (uncontrolled servo movements) under certain conditions, but also optimized RF performance and added many useful features. It is highly recommended that all ACCESS customers upgrade to 2.X.X or later version of ISRM RF modules and receivers.
-------------------------------------------------------------------------------------------------------------------
How to update internal module TD ISRM:
By radio (SD card) :
1. Put the firmware under the folder [FIRMWARE] of sd card.
2. Power on the radio and find the firmware,select it by press [ENT].
3. Select 'Flash int. module', wait to end.
---------------------------------------------------------------------------------------------------------------------
More details please check FrSky website:
https://www.frsky-rc.com/tandem-x18/
https://www.frsky-rc.com/tandem-x18s/
https://www.frsky-rc.com/tandem-x18se/
https://www.frsky-rc.com/tandem-x20/
https://www.frsky-rc.com/tandem-x20s/
https://www.frsky-rc.com/tandem-x20-hd/
https://www.frsky-rc.com/tandem-xe/

**********************All rights reserved to FrSky Electronic ., Ltd.*********************************
 