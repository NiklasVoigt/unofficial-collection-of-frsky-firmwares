
*******************************Release Note******************************************
This Package is for TD-ISRM Pro module of TANDEM radios v1.1.11 firmware update. 

Version and Files: 
TD-ISRMPro_1.1.11.frsk 
Upgrade file for the upgrade TD-ISRM Pro module for TANDEM X20 Pro.

readme.txt                                                         


Release note 
Firmware Version: v1.1.11
--------------------------------------------------------------------------------------------------------------------
1.The first firmware for newly released products.

-------------------------------------------------------------------------------------------------------------------
How to update TD-ISRM Pro internal module by radio (SD card) :
1. Put the firmware under the folder [FIRMWARE] of sd card.
2. Power on the radio and find the firmware, select it by press [ENT].
3. Select 'Flash int. module', wait to end.

---------------------------------------------------------------------------------------------------------------------
More details please check FrSky website:
https://www.frsky-rc.com/tandem-x20-pro/

**********************All rights reserved to FrSky Electronic ., Ltd.*********************************
 