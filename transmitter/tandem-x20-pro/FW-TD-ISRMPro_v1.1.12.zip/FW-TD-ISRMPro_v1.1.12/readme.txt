
*******************************Release Note******************************************
This Package is for TD-ISRM Pro module of TANDEM radios v1.1.12 firmware update. 

Version and Files: 
TD-ISRMPro_1.1.12.frsk 
Upgrade file for the upgrade TD-ISRM Pro module for TANDEM X20 Pro.

readme.txt                                                         


Release note 
Firmware Version: v1.1.12
--------------------------------------------------------------------------------------------------------------------
1. Fixed the issue that the model with 2.4G ACCST mode failed to work after switching from the model set with other protocols. 
2. Fixed the issue of RSSI alarms while staying in the Info menu.
3. Improved the switching speed of telemetry between RX1/RX2/RX3 in TD mode.
4. Added the support of telemetry data transmission through 2.4G links in the TD mode (The telemetry via 2.4G links can be also achieved under sufficient range with the RF power settings above 25mW in EU mode). 
Note: Please ensure the firmware of TD receivers is updated to the latest version. 

-------------------------------------------------------------------------------------------------------------------
How to update TD-ISRM Pro internal module by radio (SD card) :
1. Put the firmware under the folder [FIRMWARE] of sd card.
2. Power on the radio and find the firmware, select it by press [ENT].
3. Select 'Flash int. module', wait to end.

---------------------------------------------------------------------------------------------------------------------
More details please check FrSky website:
https://www.frsky-rc.com/tandem-x20-pro/

**********************All rights reserved to FrSky Electronic ., Ltd.*********************************
 