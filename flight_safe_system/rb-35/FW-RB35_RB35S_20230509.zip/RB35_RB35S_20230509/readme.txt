
*******************************Release Note******************************************

This Package is for RB35 | RB35S firmware update. 

Version and Files: 
RB35_RB35S_20230509.frsk  (Upgrade file for the RB35 | RB35S)                           
                                                 

Release Note (Firmware Version: v20230509)
--------------------------------------------------------------------------------------------------------------------
1. Fixed the issue of loss of partial sensor data with multiple receivers in connection.
2. Fixed the issue that the pitch angle sometimes fails in Hover mode.
3. Added the support of compatibility with some 3rd party sensors. 

---------------------------------------------------------------------------------------------------------------------


---------------------------------------------------------------------------------------------------------------------
More details please check FrSky website:
https://www.frsky-rc.com/product/rb-35/
https://www.frsky-rc.com/product/rb-35s/

**********************All rights reserved to FrSky Electronic ., Ltd.*********************************
 