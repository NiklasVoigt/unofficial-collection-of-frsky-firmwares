
*******************************Release Note******************************************

This Package is for the Remote NFC Panel firmware update.

Version and Files: 
RemoteNFC_20231024.frsk             Upgrade file for the Remote NFC Panel.

Readme.txt                                                         


Release note 
Firmware Version【20231024】
-------------------------------------------------------------------------------------------------------------------
1. Added the support of remote power control feature. (Please ensure the ETHOS is updated to V1.5.0 or later versions.)

-------------------------------------------------------------------------------------------------------------------


How to update RemoteNFC Panel by ETHOS radios:
1. Copy the firmware under the folder [FIRMWARE] of the SD card.
2. Move to the [File Manager] menu, and select the firmware.
3. Press the enter button, and select [Flash External Device] to start the flash progress.
4. Poping up a window displaying "Success" means the FW updating of the device is completed.


---------------------------------------------------------------------------------------------------------------------
More details please check FrSky website:
https://www.frsky-rc.com/product/remotenfc-panel/

**********************All rights reserved to FrSky Electronic ., Ltd.*********************************
 