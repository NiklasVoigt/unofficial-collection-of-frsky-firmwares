IMPORTANT NOTE!

RB10_T9TO16.frk

- inofficial firmware file
- based on Ver 170123
- Outputs Channel 9-16 instead of 1-8
- telemetry problems of g-rx8 and r-xsr are fixed later in Ver 171010

Thanks F. J. Hahn
