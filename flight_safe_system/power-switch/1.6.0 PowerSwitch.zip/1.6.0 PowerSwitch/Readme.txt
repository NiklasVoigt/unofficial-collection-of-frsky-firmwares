
*******************************Release Note******************************************

This Package is for the PowerSwitch firmware update.

Packet Files 
- Upgrade file for the PowerSwitch.
- Readme.txt                                                         


Release Note 
Firmware Version【v1.6】
-------------------------------------------------------------------------------------------------------------------
1. Fixed the issue of voltage setting not being saved when the Lua voltage setting is the same as the voltage set by the module button.

-------------------------------------------------------------------------------------------------------------------


How to update PowerSwitch module by ETHOS radios:
1. Please ensure the device is connected to the ETHOS radio by S.Port.
2. Copy the firmware under the folder [FIRMWARE] of the SD card.
3. Move to the [File Manager] menu, and select the firmware.
4. Press the enter button, and select [Flash External Device] to start the flash progress.
5. Poping up a window displaying "Success" means the FW updating of the device is completed.


---------------------------------------------------------------------------------------------------------------------
More details please check FrSky website:
https://www.frsky-rc.com/product/power-switch/

**********************All rights reserved to FrSky Electronic ., Ltd.*********************************
 