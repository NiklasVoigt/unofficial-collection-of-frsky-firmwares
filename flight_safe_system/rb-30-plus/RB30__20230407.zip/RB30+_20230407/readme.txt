
*******************************Release Note******************************************

This Package is for RB30+ firmware update. 

Version and Files: 
RB30+_20230407.frk                            Upgrade file for the RB30+.


readme.txt                                                         Release note 
 
Firmware Version: v20230407

The released firmware changes are as below:
--------------------------------------------------------------------------------------------------------------------
1. Fixed the issue of the output voltage change of BEC after repowering the device. 
2. Fixed the reading issue for battery consumption while connecting the BAT1 only.
---------------------------------------------------------------------------------------------------------------------


---------------------------------------------------------------------------------------------------------------------
More details please check FrSky website:
https://www.frsky-rc.com/product/rb-30-plus/

**********************All rights reserved to FrSky Electronic ., Ltd.*********************************
 