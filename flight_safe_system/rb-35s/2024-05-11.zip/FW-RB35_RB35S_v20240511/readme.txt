
*******************************Release Note******************************************

This Package is for RB35&RB35S firmware update. 

Version and Files: 
- RB35_v20240511.frsk
- RB35S_v20240511.frsk
- readme.txt                            
                                                 

Release Note 
Firmware Version【v20240511】
Note: Please ensure you are using the latest V3.0.0 Lua scripts to configure the Stab device with flashed this firmware version. The older Stab Lua tools or the Stab tools in Device Config (ETHOS's integration) are not compatible.  

1. Added the Reset function to recover the Stab settings to the factory settings. 
2. Added the AUX mode option to each Stab channel.
3. Cancelled the operation requiring putting the Throttle stick to the lowest (＜1000us) while doing the Self-Check.
4. Added the Stick Priority function for Stab channels
Notice: Please Reset your stab device (by Lua tool) after flashing with this firmware version, and reconfigure it to make sure it can work properly. 
--------------------------------------------------------------------------------------------------------------------
Firmware Version【v20230509】
--------------------------------------------------------------------------------------------------------------------
1. Fixed the issue of loss of partial sensor data with multiple receivers in connection.
2. Fixed the issue that the pitch angle sometimes fails in Hover mode.
3. Added the support of compatibility with some 3rd party sensors. 

---------------------------------------------------------------------------------------------------------------------


---------------------------------------------------------------------------------------------------------------------
More details please check FrSky website:
https://www.frsky-rc.com/product/rb-35/
https://www.frsky-rc.com/product/rb-35s/

**********************All rights reserved to FrSky Electronic ., Ltd.*********************************
 