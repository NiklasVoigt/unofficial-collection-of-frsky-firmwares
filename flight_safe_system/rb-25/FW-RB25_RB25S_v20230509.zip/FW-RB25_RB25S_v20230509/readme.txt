
*******************************Release Note******************************************

This Package is for RB25 & RB25S Firmware Update. 

Version and Files: 
- RB25_v20230509.frsk 
- RB25S_v20230509.frsk    
- readme.txt                                         


Release Note 
v20230509
1. Fixed the unstable telemetry issue while connecting multiple FBUS receivers at the same time.
-------------------------------------------------------------------------------------------------------------------

Note: The firmware upgrade for the RB device is supported by wiring to the S.Port of the radio to complete.
---------------------------------------------------------------------------------------------------------------------
More details please check FrSky website.
https://www.frsky-rc.com/rb-25-rb-25s/

**********************All rights reserved to FrSky Electronic ., Ltd.*********************************
