
*******************************Release Note******************************************

This Package is for receiver NEURON2 80 firmware update. 

Version and Files: 
NEURON2_80_11_3.hex                            Upgrade file for the NEURON2 80 ESC.
readme.txt                                                         

Release note 
Firmware Version: 11_3
--------------------------------------------------------------------------------------------------------------------
1. Added the support of using the LUA script to do the configuration in S.Port mode.  
2. Improved the response time of ESC telemetry
--------------------------------------------------------------------------------


How to update NEURON2 ESCs
-------------------------------------------------------------------------------
By Webpage Configurator: https://gui.fettec.net/FrSky/ESC/
Instrunctional Steps: https://www.frsky-rc.com/wp-content/uploads/Downloads/Amanual/Neuron%20II%2080%20Manual.pdf


---------------------------------------------------------------------------------------------------------------------
More details please check FrSky website:
https://www.frsky-rc.com/neuron2-80/

**********************All rights reserved to FrSky Electronic ., Ltd.*********************************
 