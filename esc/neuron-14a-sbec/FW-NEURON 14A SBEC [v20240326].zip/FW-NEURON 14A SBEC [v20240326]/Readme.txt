
*******************************Release Note******************************************

This Package is for receiver Neuron 14A SBEC firmware update. 

Version and Files: 
SBEC_14A_20240326.frsk                            Upgrade file for the Neuron 14A SBEC.
readme.txt                                                         


Release Note 
Firmware Version【20240326】
--------------------------------------------------------------------------------------------------------------------
1. Fixed the issue of failing to change some parameters (appid, phyid, etc.) when using Device Config tools.
--------------------------------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------------------------------
How to update the S.Port device by ETHOS radios:
1. Lead the S.Port wire of the SBEC to the S.Port of ETHOS radio
2. Move to the [File manager], and select the FW.
3. Press the enter button and select [Flash external device].
4. [*Important] Powering the SBEC once the flashing bar pops up. 
5. The flashing process starts and the transmitter will display [Success] if the process is completed.

---------------------------------------------------------------------------------------------------------------------
More details please check FrSky website:
https://www.frsky-rc.com/product-category/accessories/sbec/

***************************All rights reserved to FrSky Electronic ., Ltd.*********************************
 