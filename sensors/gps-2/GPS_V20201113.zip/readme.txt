
*******************************Release Note******************************************

Version and Files: 
GPS Sensor                        
readme.txt                                         
                                         
Firmware Version: 20201113

The release firmware resolved the issues below:
--------------------------------------------------------------------------------------------------------------------
1.  Increase navigation update rate to 10HZ.
-------------------------------------------------------------------------------------------------------------------
How to increase navigation update rate to 10HZ:

1. Connect the GPS sensor to the S.Port2 of STK tool, and switch the Dip to “UPGRADE” mode for flashing the firmware to the latest.
2. Find the device in the list and press the “Configure” button in FreeLink App.
3. Then edit the "Latitude and Longitude DataRate" to “100” ms (or as you wish) and “Write” to the device.

FreeLink App (PC) Download: https://www.frsky-rc.com/stk/

Note: This sensor is still supported with flashing firmware by s.port wire connection to a radio.
---------------------------------------------------------------------------------------------------------------------
More details please check FrSky website.
https://www.frsky-rc.com/gps/

**********************All rights reserved to FrSky Electronic ., Ltd.*********************************
