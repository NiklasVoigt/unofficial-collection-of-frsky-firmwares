
*******************************Release Note******************************************

Version and Files: 
ASS-70_ADV_1.6.frsk                  
readme.txt                                         


Firmware Version: V1.6

• Fixed the issue that the sensor does not work in FBUS 8ch or 24ch mode.
---------------------------------------------------------------------------------------------------------------------------------                                         
Firmware Version: V1.5

The release firmware resolved the issues below:
--------------------------------------------------------------------------------------------------------------------
First release.
---------------------------------------------------------------------------------------------------------------------------------
How to upgrade Sensors by S.Port please refer to the info below:

With radios which have s.port 
1.Connect the sensor with the radio by S.Port.
2. Put the firmware under the folder [FIRMWARE] of sd card.
3. Power on the radio and find the firmware,select it by press [ENT].
4. Select 'Flash S.port ', wait to end.

With Airlink S :
https://www.frsky-rc.com/how-to-upgrade-the-s-series-receivers-with-the-s-port-airlink-s/

With STK:
https://www.frsky-rc.com/how-to-use-frsky-stk-tool-to-update-firmware/


More details please check FrSky website.
https://www.frsky-rc.com/ass70-adv/

**********************All rights reserved to FrSky Electronic ., Ltd.*********************************
