
*******************************Release Note******************************************

Version and Files: 
ASS-70_20210318.frsk
ASS-100_20210318.frsk                     
readme.txt                                         
                                         
Firmware Version: 20210318

The release firmware resolved the issues below:
--------------------------------------------------------------------------------------------------------------------
Solve problems with incompatible ACCESS receivers

---------------------------------------------------------------------------------------------------------------------------------
How to upgrade Sensors by S.Port please refer to the info below:

With radios which have s.port 
1.Connect the sensor with the radio by S.Port.
2. Put the firmware under the folder [FIRMWARE] of sd card.
3. Power on the radio and find the firmware,select it by press [ENT].
4. Select 'Flash S.port ', wait to end.

With Airlink S :
https://www.frsky-rc.com/how-to-upgrade-the-s-series-receivers-with-the-s-port-airlink-s/

With STK:
https://www.frsky-rc.com/how-to-use-frsky-stk-tool-to-update-firmware/


More details please check FrSky website.
https://www.frsky-rc.com/product-category/sensors/airspeed/

**********************All rights reserved to FrSky Electronic ., Ltd.*********************************
